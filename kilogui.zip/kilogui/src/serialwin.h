#ifndef SERIALWINDOW_H
#define SERIALWINDOW_H

//NOTE: Michael Otte @ UMD added a lot more include directories in 2024 to fix issues with missing files (qt5 seems to have been the problem)

#include <QPushButton>
#include <QVBoxLayout>
#include <QWidget>
#include <QString>

class QTextEdit;

class SerialWindow: public QWidget {
    Q_OBJECT

public:
    SerialWindow(QString title, QWidget *parent = 0);

public slots:
    void addText(QString);
    void clear();

private:
    QTextEdit *text_edit;
};

#endif//SERIALWINDOW_H
