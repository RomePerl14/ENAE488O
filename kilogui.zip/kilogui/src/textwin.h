// NOTE: Michael Otte @ UMD added another include directory in 2024 to fix issues with missing files (qt5 seems to have been the problem)

#ifndef TEXTWINDOW_H
#define TEXTWINDOW_H

#include <QWidget>
#include <QString>
#include <QPushButton>
#include <QVBoxLayout>
#include <QWidget>
#include <QtGui>
#include <QTextEdit>

class QTextEdit;

class TextWindow: public QWidget {
    Q_OBJECT

public:
    TextWindow(QString title, QWidget *parent = 0);

public slots:
    void addText(QString);
    void clear();

private:
    QTextEdit *text_edit;
};

#endif//TEXTWINDOW_H
