#ifndef CALIBWINDOW_H
#define CALIBWINDOW_H


//NOTE: Michael Otte @ UMD added a lot more include directories in 2024 to fix issues with missing files (qt5 seems to have been the problem)

#include <QPushButton>
#include <QVBoxLayout>
#include <QLabel>
#include <QWidget>
#include <QString>
#include <QSpinBox>

class CalibWindow: public QWidget {
    Q_OBJECT

public:
    CalibWindow(QString title, QWidget *parent = 0);
    void closeEvent(QCloseEvent *);

signals:
    void calibUID(int);
    void calibLeft(int);
    void calibRight(int);
    void calibStraight(int);
    void calibSave();
    void calibStop();

public slots:
    void updateCalib(int);
    void save();

private:
    QSpinBox *values[5];    
};

#endif//CALIBWINDOW_H
